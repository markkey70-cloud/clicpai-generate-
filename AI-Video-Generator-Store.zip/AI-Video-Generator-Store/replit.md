# Video AI Store

Video AI Store is a Replicate-powered web app for creating short AI videos from prompts and presenting credit packs for creators.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run test:refund` — test credit refunds against the development DB using temporary records
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/video-ai-store/src/` — React/Vite storefront, creation studio, history, and pricing screens.
- `artifacts/api-server/src/routes/video.ts` — Replicate-backed model catalog and prediction endpoints.
- `lib/api-spec/openapi.yaml` — source of truth for video model and prediction contracts.
- `lib/api-client-react/src/generated/` and `lib/api-zod/src/generated/` — generated client hooks and server validators.

## Architecture decisions

- Replicate is called server-side through the Replit-managed connector so credentials never reach browser code.
- Prediction records and credit reservations are persisted in PostgreSQL; the background worker reconciles unfinished videos and automatically refunds failed, canceled, or abandoned starts.
- The frontend uses generated OpenAPI hooks so request and response shapes stay aligned with the API.

## Product

- Create short videos from a text prompt with a curated Replicate model list.
- Track generation progress and open completed video outputs.
- Browse recent generations and review credit-pack pricing.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
