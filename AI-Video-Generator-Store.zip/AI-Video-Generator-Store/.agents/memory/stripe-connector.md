---
name: Stripe connector
description: Runtime constraint for Stripe access in this project.
---

Use the Replit Stripe connector proxy from server code instead of expecting a Stripe secret key or webhook secret in the workflow environment.

**Why:** The connected Stripe integration exposes a healthy proxy connection but did not provide the secret-key field required by the StripeSync startup template, which caused the API workflow to fail before serving requests.

**How to apply:** Keep Stripe requests server-side through the connector SDK proxy. If implementing webhook-driven synchronization later, confirm the connector's webhook capabilities first; otherwise poll Stripe API state and reconcile it into the application database.

When checking live payments through the agent's Stripe connection, select the production environment explicitly and confirm Stripe reports live mode. Do not assume the first available connection is production.

**Why:** This workspace can expose both a development test connection and a production live connection at once. A real live payment appeared missing through the first connection but was found and paid through the production connection.

**How to apply:** Inspect the available connection environments without exposing credentials. For live payment lookups, use the production connection and verify the returned payment and Checkout Session, including status, amount, duration, and billing ownership, before discussing credits.

Verify `livemode` on the actual PaymentIntent and Checkout Session. In this workspace, `/v1/account` reported `livemode=false` even though the production connection returned a live, paid PaymentIntent and its live Checkout Session.

**Why:** The account-level mode response conflicted with the transaction objects, so relying on `/v1/account` alone would have incorrectly rejected a verifiable live payment.

**How to apply:** Treat the PaymentIntent and Checkout Session mode fields as the transaction evidence. If they conflict with the account-level mode, flag the mismatch and verify the exact live transaction's status, amount, currency, duration, and owner before crediting.

A verified live Checkout can be visible to the agent's production Stripe connection while the published API's generic connector lookup returns "No such checkout.session"—the same response as the development connection.

**Why:** This happened during confirmation of a paid purchase. It points to a published-runtime connection binding or selection mismatch, not an unpaid charge.

**How to apply:** Compare the exact session through both connection environments and the deployed confirmation logs. Fix production connector routing before retrying the app's idempotent confirmation; never ask the customer to pay again or add credit without the verified flow.