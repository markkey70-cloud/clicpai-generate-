---
name: Affordable sound generation
description: Cost constraint for adding music or sound effects to generated videos.
---

Do not use a $0.20-per-output audio-generation model as the default for this video store; the owner considers that price too high. The owner chose to offer both lower-cost short prompt-generated music/effects and user-uploaded licensed audio.

**Why:** Customer-triggered sound generation can incur repeated provider charges, and the owner explicitly rejected that per-output cost.

**How to apply:** Keep narration separate. Use a lower-cost model only after checking commercial-use eligibility and agreeing on who pays per generation; uploads should add no generation fee. Pexels supplies visual stock media, not music or sound effects.

The low-cost Stable Audio Open deployment can return a full-length WAV even when asked for only a few seconds. Its first run also waited over two minutes to boot, while measured inference took only seconds.

**Why:** Requested sample length is not a reliable measure of output-file length or first-run latency; a synchronous export can time out near cold-start durations.

**How to apply:** Trim or pad audio against the actual video length, allow several minutes for a cold start, and distinguish waiting time from billable inference when estimating provider cost. Commercial use of this model has an annual-revenue limit and attribution requirements; confirm eligibility before publishing.