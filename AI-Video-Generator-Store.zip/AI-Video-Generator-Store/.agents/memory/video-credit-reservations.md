---
name: Video credit reservations
description: Billing rule for protecting video generation credits.
---

Video generation must reserve the required integer credit amount atomically before calling the provider, and the billing account must have a confirmed paid-credit purchase or an unexpired active paid subscription. Signup and free-trial balances are not generation entitlements. Each debit must have a durable reservation created in that same transaction; every refund must claim that reservation once and restore the account in the same transaction. Reconcile untracked charges after a safe grace period following a crash. Do not infer historical refund amounts from current model prices.

**Why:** Displaying a balance without reserving credits lets users generate without payment and concurrent requests can overspend the same balance. Historical signup defaults can also look spendable even when no payment exists. A process can stop between debit and provider-result persistence, so an in-memory refund attempt is not enough. Concurrent requests can also each observe the same terminal failure, making an atomic claim essential.

**How to apply:** Resolve the signed-in user to their billing account, atomically require sufficient balance plus a verified payment source, show zero usable credits without that source, refresh the client balance after success, and return an explicit insufficient-credit response instead of calling Replicate. Retry unsettled terminal video failures and abandoned starts after restart; a failed voice-processing step on an otherwise successful video is retryable and must not trigger a full video refund.