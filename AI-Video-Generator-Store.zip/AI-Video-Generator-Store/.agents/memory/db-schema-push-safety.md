---
name: Safe additive database changes
description: Drizzle push may demand a destructive confirmation for a safe nullable unique field on a populated table.
---

Do not force an interactive Drizzle schema push when it proposes truncating populated data just to add an otherwise safe nullable unique field. Verify the intended database and apply a strictly additive SQL change instead.

**Why:** In this workspace Drizzle's non-interactive push prompted for truncation while adding a nullable unique constraint, although existing rows could safely retain null values. Accepting a force path would risk deleting customer video history.

**How to apply:** Inspect the existing table and row count, confirm the development database is the one the application uses, add only the required table/column/index, and verify the records remain intact. Do not interpret this as permission to mutate an external production database.