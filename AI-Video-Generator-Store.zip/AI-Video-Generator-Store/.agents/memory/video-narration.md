---
name: Integrated video voices
description: User-selected voice behavior for generated videos and their normal download.
---

Customers choose either a typed script for AI narration or their own recording before generating a video. Finish voice processing automatically, save the voiced MP4 privately, and make ordinary playback and the single Download video action use that final file. Keep Add sound separate for optional music and effects.

Typed narration offers adult masculine, adult feminine, and fictional youthful voice styles. Preserve the selected style through processing retries and saved playback.

**Why:** The user explicitly chose both voice inputs and rejected a separate “Add voice & download” step. They want the finished video available later in history even if they leave the page. An older worker can finish after a retry, so it must not replace the selected final file or cause another avoidable synthesis charge.

**How to apply:** Validate recordings before reserving credits; process selected voice server-side after video generation; keep original and voiced attempts separate and fence the chosen result by the current claim; reuse synthesized narration on retry; hide unfinished or failed results from the normal download; make failures retryable without regenerating the video.