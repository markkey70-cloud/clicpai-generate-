---
name: Checkout payer email and credit ownership
description: Product decision for separate Stripe payer emails and signed-in account ownership.
---

Allow the authenticated customer to enter a different payer or receipt email at Checkout. Purchased credits remain attached to the signed-in account.

**Why:** The user explicitly chose to separate the payment email from account identity without transferring credit ownership.

**How to apply:** Send the entered payer email to Stripe, but preserve the authenticated account identity in Checkout metadata and authorize confirmation and credit assignment against the signed-in account. Do not use Stripe's customer email as the account owner when authenticated ownership metadata is available.