---
name: Reference image privacy
description: Privacy and product rules for product and avatar reference images used in video generation.
---

Support both product photos and person/avatar photos as optional video-generation references. Keep uploads private and scoped to the signed-in user, and give video providers only short-lived access URLs.

**Why:** The owner explicitly chose both use cases. These images may contain customer products, branding, or identifiable people and must not become public assets.

**How to apply:** Never accept arbitrary remote image URLs from the browser, expose permanent storage URLs, or reuse another user's upload. Preserve product details for product mode and personal appearance for avatar mode.