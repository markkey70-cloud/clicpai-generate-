---
name: Persistent generated videos
description: Retention and access rules for completed generated video files.
---

Completed provider outputs must be copied into private App Storage as soon as they succeed. Playback, silent downloads, and voiced downloads must use an authenticated API route that verifies prediction ownership.

**Why:** Replicate delivery URLs expire and may later return 404 or disappear from the prediction output, making database history records unplayable and impossible to download.

**How to apply:** Retry archival when an older successful record is opened or listed while a provider output is still recoverable. Do not expose signed storage URLs or make generated customer videos public.