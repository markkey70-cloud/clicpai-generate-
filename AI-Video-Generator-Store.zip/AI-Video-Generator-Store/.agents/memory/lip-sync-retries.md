---
name: Lip-sync retries
description: Retry behavior for paid lip-sync provider jobs.
---

Persist the provider prediction ID as soon as Replicate accepts a lip-sync job, then resume that job after a worker restart instead of creating a second prediction. Keep the ID when polling or output storage fails; clear it after a terminal provider failure or successful archive.

**Why:** A worker can restart after a paid provider job has started but before its output is archived. Retrying with no saved provider ID would start another paid generation.

**How to apply:** For future paid video-processing stages, store the provider job ID under the user's prediction, use the existing processing claim to guard updates, and reuse the ID until the job reaches a terminal failure or the output is safely stored.