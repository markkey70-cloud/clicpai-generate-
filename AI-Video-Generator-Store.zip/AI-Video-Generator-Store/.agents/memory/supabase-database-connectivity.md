---
name: Supabase database connectivity
description: Connection requirement for applying SQL migrations to the project's Supabase database from Replit.
---

Use the Supabase session pooler in the Sydney region for direct PostgreSQL connections from this Replit environment. The project's direct `db.*.supabase.co` hostname does not provide a usable address here.

**Why:** The Supabase REST and Auth APIs are reachable, but direct database DNS resolution fails. The Sydney pooler recognizes the project and is the correct route for schema migrations.

**How to apply:** Build or copy a Session pooler connection from Supabase Connect and store it as a secret. If the pooler returns PostgreSQL `28P01`, correct or reset the database password before attempting schema changes.