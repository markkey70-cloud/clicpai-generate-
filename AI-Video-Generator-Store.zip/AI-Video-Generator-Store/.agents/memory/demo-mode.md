---
name: Live generation and billing
description: Product decision approving production Replicate rendering and real Stripe Checkout.
---

Use live Replicate video generation and real Stripe-hosted Checkout. Simulation mode is fully retired.

**Why:** The owner explicitly approved provider charges and real customer payments after confirming the 10-second THB simulation.

**How to apply:** Generation may incur Replicate costs. Checkout must create and verify real Stripe sessions server-side; never reintroduce fake checkout success URLs or simulated payment copy.