---
name: Pay-as-you-go Stripe prices
description: Operational constraint when validating the live Stripe price matrix.
---

When auditing live pay-as-you-go prices, inspect the exact active `video_seconds` product returned first by Stripe's product search, not just prices across all matching products. The checkout lookup selects the first product and only searches that product's active prices; missing entries are attempted as on-demand Stripe Price creations.

**Why:** Production returned two active products with the same metadata key but uneven price coverage. A duration's price can exist on the second product while checkout ignores it; the live matrix was also incomplete on the first product.

**How to apply:** Before declaring every tier ready, compare each currency/duration on the selected product. Treat on-demand price creation as unverified until checkout creation is tested; do not create live prices during a read-only audit.