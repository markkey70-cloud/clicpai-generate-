---
name: Replicate connector
description: The app should use the Replit-managed Replicate connector for server-side generation requests.
---

Use Replicate as the only video-generation provider. Keep Hailuo on the verified `minimax/hailuo-2.3` Replicate model and route all generation from the API server instead of exposing provider credentials to the browser.

**Why:** The owner chose Replicate-only generation and confirmed the existing Hailuo route is the preferred affordable path over adding Gemini, whose video pricing was too high. The managed connection also keeps provider authentication out of client code.

**How to apply:** Keep Replicate calls behind API routes, use exact verified Replicate model IDs, and let the frontend consume generated OpenAPI hooks. Do not add direct Pika, MiniMax, or other provider clients unless the owner changes this decision.